const CACHE_NAME = 'eram-geomatics-v1';
const CORE_ASSETS = ['./','./index.html','./manifest.webmanifest','./assets/eram-logo.png','./assets/eram-app-icon-192.png','./assets/eram-app-icon-512.png','./assets/favicon-32.png','./assets/favicon-64.png','./assets/apple-touch-icon.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(CORE_ASSETS))); self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))); self.clients.claim(); });
self.addEventListener('fetch', e => { if (e.request.method !== 'GET') return; e.respondWith(caches.match(e.request).then(cached => cached || fetch(e.request).then(response => { const copy=response.clone(); if(new URL(e.request.url).origin===self.location.origin) caches.open(CACHE_NAME).then(c=>c.put(e.request,copy)); return response; }).catch(()=>caches.match('./index.html')))); });
